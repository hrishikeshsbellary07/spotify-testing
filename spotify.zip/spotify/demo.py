from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
import time


chromedriver_path = r'C:\Users\bella\Downloads\chromedriver_py-126.0.6478.126\chromedriver_py-126.0.6478.126\chromedriver_py\chromedriver_win64.exe'

service = Service(chromedriver_path)
driver = webdriver.Chrome(service=service)

driver.get('https://open.spotify.com/playlist/0eWPIR1Us5qZOjDwxgIoQX')

driver.maximize_window()

wait = WebDriverWait(driver, 10)
email_field = wait.until(EC.presence_of_element_located((By.ID, 'login-username')))
password_field = wait.until(EC.presence_of_element_located((By.ID, 'login-password')))
login_button = wait.until(EC.element_to_be_clickable((By.ID, 'login-button')))

email_field.send_keys('bellaryhrishikesh@gmail.com')
password_field.send_keys('iamrichman')

login_button.click()

web_player_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, "//*[@id='root']/div/div/div/div/button[2]/span[2]"))
)
web_player_button.click()

search_icon_xpath = '//*[@id="Desktop_LeftSidebar_Id"]/nav/div[1]/ul/li[2]/a'
search_icon = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, search_icon_xpath))
)
search_icon.click()

search_box_xpath = '//*[@id="main"]/div/div[2]/div[3]/header/div[2]/div[2]/div/div/form/input'
search_box = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located((By.XPATH, search_box_xpath))
)
search_box.send_keys("Gangnam Style")
search_box.send_keys(Keys.RETURN)

wait = WebDriverWait(driver, 10)
button = wait.until(EC.element_to_be_clickable((By.XPATH, '//*[@id="main"]/div/div[2]/div[3]/div[1]/div[2]/div[2]/div[2]/main/div[1]/div/div/div[1]/div/a[2]/button/span')))
button.click()

gangamstyle_xpath='//*[@id="searchPage"]/div/div/div/div[1]/div[2]/div[2]/div[1]/div/div[2]/div/a/div'
first_result = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, gangamstyle_xpath))
)
first_result.click()

play_button_xpath = '//*[@id="main"]/div/div[2]/div[3]/div[1]/div[2]/div[2]/div[2]/main/section/div[3]/div[2]/div/div/div/button/span'
play_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, play_button_xpath))
)
play_button.click()


home_button_xpath = '//*[@id="Desktop_LeftSidebar_Id"]/nav/div[1]/ul/li[1]/a'
home_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, home_button_xpath))
)
home_button.click()

plus_button_xpath='//*[@id="Desktop_LeftSidebar_Id"]/nav/div[2]/div[1]/div[1]/header/div/span/button'
plus_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, plus_button_xpath))
)
plus_button.click()

create_playlist_xpath='//*[@id="context-menu"]/ul/li[1]/button/span'
create_playlist = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, create_playlist_xpath))
)
create_playlist.click()

search=WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//*[@id="main"]/div/div[2]/div[3]/div[1]/div[2]/div[2]/div[2]/main/div[1]/section/div[2]/div[3]/section/div/div/input'))
)
search.send_keys("Pray for me")
search.send_keys(Keys.RETURN)

add_to_playlist_id = "add-to-playlist-button"
add_to_playlist = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.ID, add_to_playlist_id)))
add_to_playlist.click()


play_button_xpath = "//button[@aria-label='Play Top 100 kannada songs']//span[@class='IconWrapper__Wrapper-sc-1hf1hjl-0 bjlVXn']//*[name()='svg']//*[name()='path' and contains(@d,'m7.05 3.60')]"
play_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, play_button_xpath))
)
play_button.click()

time.sleep(5000)