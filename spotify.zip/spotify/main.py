from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.action_chains import ActionChains
import time


chromedriver_path = r'C:\Users\bella\Downloads\chromedriver_py-126.0.6478.126\chromedriver_py-126.0.6478.126\chromedriver_py\chromedriver_win64.exe'

service = Service(chromedriver_path)
driver = webdriver.Chrome(service=service)

driver.get('https://open.spotify.com/playlist/0eWPIR1Us5qZOjDwxgIoQX')

driver.maximize_window()
play_button_xpath = "//button[@aria-label='Play Top 100 kannada songs']//span[@class='IconWrapper__Wrapper-sc-1hf1hjl-0 bjlVXn']//*[name()='svg']//*[name()='path' and contains(@d,'m7.05 3.60')]"
play_button = WebDriverWait(driver, 10).until(
    EC.element_to_be_clickable((By.XPATH, play_button_xpath))
)
play_button.click()

time.sleep(5000)